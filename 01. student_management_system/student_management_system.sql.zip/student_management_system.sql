-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 14, 2024 at 03:22 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `student_management_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `course_id` int(225) NOT NULL,
  `course_name` varchar(30) NOT NULL,
  `credit_hours` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`course_id`, `course_name`, `credit_hours`) VALUES
(21100, 'Physics', 3),
(21101, 'Programming Fundamentals', 3),
(21103, 'Database System', 3),
(21104, 'Operating System', 3),
(21105, 'English', 2),
(21109, 'EFCore', 3),
(21110, 'Programming Fundamentals', 3),
(21121, 'DLDesign', 3),
(21201, 'Data Structure', 3),
(21203, 'Web Programming', 3),
(21206, 'Software Engineering - 1', 3),
(21301, 'Networking', 3),
(23301, 'Development', 3);

-- --------------------------------------------------------

--
-- Table structure for table `degree`
--

CREATE TABLE `degree` (
  `d_id` int(225) NOT NULL,
  `name` varchar(225) NOT NULL,
  `fee` int(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `degree`
--

INSERT INTO `degree` (`d_id`, `name`, `fee`) VALUES
(10, 'MCS', 27150),
(11, 'BSCS', 32150),
(12, 'MSIT', 44950),
(13, 'MSE,SE', 49950),
(14, 'BSIT', 32150),
(15, 'PHB', 78350),
(16, 'MSCS', 27150),
(17, 'BSSE', 32150),
(18, 'MA', 25000),
(3112, 'M.A', 88000),
(311290, 'PHd', 40000),
(311299, 'Phd. Physics', 98000);

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `student_id` int(11) NOT NULL,
  `student_name` varchar(225) NOT NULL,
  `degree` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`student_id`, `student_name`, `degree`) VALUES
(22, 'Muhammad Bilal', 'BSCS'),
(57, 'Tanzeel Tariq', 'MCS'),
(222, 'Muhammad Haris', 'BSSE'),
(322, 'Muhammad Haris', 'MA'),
(666, 'Zakir', 'MSCS'),
(3333, 'Muhammad Bilal', 'MSCS'),
(4545, 'Muhammad Haris', 'Phd. Physics');

-- --------------------------------------------------------

--
-- Table structure for table `students_courses`
--

CREATE TABLE `students_courses` (
  `d_id` int(255) NOT NULL,
  `course_id` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `students_courses`
--

INSERT INTO `students_courses` (`d_id`, `course_id`) VALUES
(10, 21101),
(10, 21103),
(11, 21121),
(12, 21104),
(12, 21301),
(13, 21103),
(13, 21110),
(13, 21206),
(14, 21301),
(15, 21109),
(15, 21203),
(16, 21101),
(16, 23301),
(17, 21104),
(17, 21105),
(18, 21104),
(18, 21121),
(18, 21301),
(3112, 21121),
(3112, 21301),
(311290, 21301),
(311299, 21103),
(311299, 21110);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `role` enum('student','admin') NOT NULL,
  `username` varchar(225) NOT NULL,
  `password` varchar(225) NOT NULL,
  `name` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `role`, `username`, `password`, `name`) VALUES
(13, 'admin', 'zaki', '81dc9bdb52d04dc20036dbd8313ed055', 'Zaki Ansari'),
(14, 'student', 'haris', '827ccb0eea8a706c4c34a16891f84e7b', 'Muhammad Haris'),
(23, 'student', 'bilal', '4a7d1ed414474e4033ac29ccb8653d9b', 'Muhammad Bilal'),
(24, 'student', 'ali', 'fa246d0262c3925617b0c72bb20eeb1d', 'Ali Hassan'),
(25, 'student', 'tanu', '4a7d1ed414474e4033ac29ccb8653d9b', 'Tanzeel Tariq'),
(26, 'admin', 'haris', '934b535800b1cba8f96a5d72f72f1611', 'Muhammad Haris'),
(27, 'student', 'bilal', '2be9bd7a3434f7038ca27d1918de58bd', 'Muhammad Bilal'),
(28, 'student', 'haris', '3b712de48137572f3849aabd5666a4e3', 'Muhammad Haris'),
(29, 'student', 'hamza', '4a7d1ed414474e4033ac29ccb8653d9b', 'Muhammad Haris');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `course`
--
ALTER TABLE `course`
  ADD PRIMARY KEY (`course_id`),
  ADD KEY `course_name` (`course_name`);

--
-- Indexes for table `degree`
--
ALTER TABLE `degree`
  ADD PRIMARY KEY (`d_id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`student_id`),
  ADD KEY `student_name` (`student_name`),
  ADD KEY `degree` (`degree`);

--
-- Indexes for table `students_courses`
--
ALTER TABLE `students_courses`
  ADD PRIMARY KEY (`d_id`,`course_id`),
  ADD KEY `course_id` (`course_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `students_courses`
--
ALTER TABLE `students_courses`
  ADD CONSTRAINT `students_courses_ibfk_1` FOREIGN KEY (`course_id`) REFERENCES `course` (`course_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `students_courses_ibfk_2` FOREIGN KEY (`d_id`) REFERENCES `degree` (`d_id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
