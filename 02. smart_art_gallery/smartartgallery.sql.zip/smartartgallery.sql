-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 23, 2024 at 02:12 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `smartartgallery`
--

-- --------------------------------------------------------

--
-- Table structure for table `artists`
--

CREATE TABLE `artists` (
  `id` int(225) NOT NULL,
  `userid` int(225) NOT NULL,
  `firstname` text NOT NULL,
  `lastname` varchar(225) NOT NULL,
  `dob` date NOT NULL,
  `email` varchar(225) NOT NULL,
  `address` varchar(225) NOT NULL,
  `city` varchar(225) NOT NULL,
  `state` varchar(225) NOT NULL,
  `postalcode` int(225) NOT NULL,
  `phone` varchar(225) NOT NULL,
  `description` varchar(9999) NOT NULL,
  `pic` varchar(225) NOT NULL,
  `status` enum('online','offline') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `artists`
--

INSERT INTO `artists` (`id`, `userid`, `firstname`, `lastname`, `dob`, `email`, `address`, `city`, `state`, `postalcode`, `phone`, `description`, `pic`, `status`) VALUES
(14, 52, 'A.Q', 'Arif', '1990-08-26', 'arif@gmail.com', 'Cattle Park, Urdu Bazar, Lahore, Pakistan', 'Lahore', 'Lahore', 123, '0300-1230006', 'In my work, I am creates dreamy, beautiful landscapes, half imagined and half real. ', 'a.q arif.jpg', 'online'),
(15, 54, '', '', '1987-03-14', 'rind@gmail.com', 'Gulshan-e-Iqbal Karachi -75300', 'Karachi ', 'Karachi', 123456, '0300-1239988', 'I am a versatile artist who graduated from CIAC(Central Institute of Art and Craft) in 1988.I was at that time a super-realist painter who continued to study art and to explore contemporary styles of painting.', 'as rind.png', 'online'),
(16, 55, 'Abdul Jabbar', 'Gull', '1990-08-06', 'abdul@gmail.com', 'Khayaban-e-Suharwardy, Islamabad, Pakistan', 'Islamabad', 'Islamabad', 1233, '0300-1999999', 'In 2003 I was awarded a National Excellence Award from the Pakistan National Council of the Arts. Exhibitions of impressive carved forms, painted interpretations and work in metal followed.', 'abdul jabbar.jpg', 'online'),
(17, 56, 'Ghulam ', 'Mustafa', '1983-09-06', 'ghulam@gmail.com', 'Phase VI, DHA, Karachi', 'Karachi', 'Karachi', 123, '0300-1234567', 'In my art, light creates myriad patterns on passers by, dazzling the observer eyes as from shadowed lanes they observe buildings and people dissolve in sunlight.', '2.jpg', 'online'),
(18, 57, 'Jamal', 'Shah', '1987-07-06', 'jamal@gmail.com', 'Behind Sindh Secretariat, Karachi, Pakistan', 'Karachi', 'Karachi', 123, '0300-1234567', 'My powerful art in the media of painting, printmaking and sculpture portrays my concerns for the advantaged people around me. ', 'IMG-62a1ca55973b23.57923089.jpg', 'online'),
(33, 64, 'Hajra', 'Mansoor', '1990-12-28', 'hajra@gmail.com', 'Karachi, Pakistan', 'Karachi', 'Sindh', 123, '0300-1234567', 'I was participated in numerous group shows in Pakistan, enlivened fashion displays and contributed to VASL activities.', 'IMG-62a1cdedee3ce1.65470053.jpg', 'online'),
(34, 63, 'Ahmed', 'Khan', '1991-09-28', 'ahmed@gmail.com', 'Multan, Pakistan', 'Multan', 'Multan', 123, '0300-1234567', 'In my work, I am creates dreamy, beautiful landscapes, half imagined and half real. ', 'IMG-62a1d4ea0e5992.45160688.jpg', 'online'),
(35, 62, 'Abdul', 'Rehman', '1985-12-07', 'aabdul@gmail.com', 'Bahawalpur, Punjab, Pakistan', 'Bahawalpur', 'Bahawalpur', 123, '0300-1234567', 'I am a versatile artist who graduated from CIAC(Central Institute of Art and Craft) in 1988.I was at that time a super-realist painter who continued to study art and to explore contemporary styles of painting.', 'IMG-62a1d4f558b543.97066090.jpg', 'online'),
(36, 58, 'Bilal', 'Tariq', '1980-12-07', 'abc@gmail.com', 'School bzaar, RYK, Pakistan', 'Rahim Yar Khan', 'Rahim Yar Khan', 7687, '0300-1234567', 'In 2003 I was awarded a National Excellence Award from the Pakistan National Council of the Arts. Exhibitions of impressive carved forms, painted interpretations and work in metal followed.', 'IMG-62a1d39c205e43.93795500.jpg', 'offline'),
(37, 59, 'Shahrukh', 'Ali', '1982-12-21', 'abc@gmail.com', 'Rahim Yar Khan, Pakistan', 'Rahim Yar Khan', 'Rahim Yar Khan', 123, '0300-1234567', 'In my art, light creates myriad patterns on passers by, dazzling the observer eyes as from shadowed lanes they observe buildings and people dissolve in sunlight.', 'IMG-62a1d4f558b543.97066090.jpg', 'online'),
(38, 61, 'Shumaila', 'Arif', '1998-12-14', 'abc@gmail.com', 'Rahim Yar Khan, Pakistan', 'Rahim Yar Khan', 'Rahim Yar Khan', 123, '0300-1234567', 'My powerful art in the media of painting, printmaking and sculpture portrays my concerns for the advantaged people around me. ', 'IMG-62a1ce5abbf507.40796867.jpg', 'offline'),
(39, 84, 'shyle', 'arif', '2023-12-30', 'arif@gmail.com', 'sani pull', 'ryk', 'punjab', 123, '0300-8841241', 'vhhdqwvwdwqhvdwydvw', 'IMG-62a1d1841427d4.06489398.jpg', 'online');

-- --------------------------------------------------------

--
-- Table structure for table `arts`
--

CREATE TABLE `arts` (
  `id` int(225) NOT NULL,
  `type` enum('calligraphy','miniature','landscape','realism','abstract','figurative') NOT NULL,
  `artist` text NOT NULL,
  `medium` varchar(225) NOT NULL,
  `size` varchar(225) NOT NULL,
  `price` int(225) NOT NULL,
  `pic` varchar(225) NOT NULL,
  `status` enum('available','sold') NOT NULL,
  `artistid` int(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `arts`
--

INSERT INTO `arts` (`id`, `type`, `artist`, `medium`, `size`, `price`, `pic`, `status`, `artistid`) VALUES
(31, 'landscape', 'A.S  Rind', 'Water Colour on Paper', '14 x 14', 200000, 'cf.jpg', 'available', 15),
(33, 'figurative', 'A.S  Rind', 'Oil on Canvas', '30 x 36', 300000, 'ch.jpg', 'available', 15),
(34, 'abstract', 'A.S  Rind', 'Water Colour on Paper', '30 x 36', 130000, 'ab1.jpg', 'sold', 15),
(35, 'figurative', 'A.S  Rind', 'Water Colour on Paper', '20 x 20', 150000, 'da.jpg', 'available', 15),
(36, 'figurative', 'A.S  Rind', 'Ink Pen on Paper', '14 x 14', 500000, 'dc.jpg', 'available', 15),
(38, 'miniature', 'A.S  Rind', 'Water Colour on Paper', '30 x 36', 130000, 'ef.jpg', 'available', 15),
(39, 'miniature', 'A.S  Rind', 'Oil on Canvas', '14 x 14', 130000, 'eh.jpg', 'sold', 15),
(40, 'figurative', 'A.S  Rind', 'Water Colour on Paper', '30 x 36', 200000, 'fg1.jpg', 'available', 15),
(41, 'calligraphy', 'A.S  Rind', 'Ink Pen on Paper', '20 x 20', 150000, 'bi.jpg', 'sold', 15),
(42, 'calligraphy', 'A.S  Rind', 'Water Colour on Paper', '30 x 36', 200000, 'bk.jpg', 'sold', 15),
(45, 'calligraphy', 'Hajra Mansoor', 'Oil Paint', '25 x 25', 100000, 'WhatsApp Image 2022-12-27 at 9.55.25 PM (1).jpeg', 'sold', 33),
(46, 'calligraphy', 'Hajra Mansoor', 'Oil Paint', '22 x 30', 200000, 'WhatsApp Image 2022-12-27 at 9.47.39 PM (2).jpeg', 'available', 33),
(47, 'calligraphy', 'Hajra Mansoor', 'Oil Paint', '14 x 14', 250000, 'WhatsApp Image 2022-12-27 at 9.47.39 PM (1).jpeg', 'available', 33),
(48, 'calligraphy', 'Hajra Mansoor', 'Oil Paint', '30 x 36', 55000, 'WhatsApp Image 2022-12-27 at 9.47.39 PM.jpeg', 'available', 33),
(49, 'miniature', 'Hajra Mansoor', 'Acrylic Paint', '14 x 14', 60000, 'WhatsApp Image 2022-12-27 at 10.06.34 PM (2).jpeg', 'available', 33),
(50, 'miniature', 'Hajra Mansoor', 'Acrylic Paint', '50000', 40000, 'WhatsApp Image 2022-12-27 at 9.55.34 PM (2).jpeg', 'available', 33),
(51, 'miniature', 'Hajra Mansoor', 'Acrylic Paint', '25 x 25', 30000, 'WhatsApp Image 2022-12-27 at 9.55.34 PM.jpeg', 'available', 33),
(52, 'calligraphy', 'Ahmed Khan', 'Oil on Canvas', '25 x 25', 200000, 'bj.jpg', 'available', 34),
(53, 'calligraphy', 'Ahmed Khan', 'Water Colour on Paper', '22 x 30', 30000, 'bk.jpg', 'available', 34),
(54, 'calligraphy', 'Ahmed Khan', 'Oil Paint', '14 x 14', 200000, 'bl.jpg', 'available', 34),
(55, 'calligraphy', 'Ahmed Khan', 'Water Colour on Paper', '30 x 36', 30000, 'bm.jpg', 'available', 34),
(56, 'miniature', 'Ahmed Khan', 'Oil on Canvas', '22 x 30', 200000, 'ea.jpg', 'available', 34),
(57, 'miniature', 'Ahmed Khan', 'Oil Paint', '22 x 30', 250000, 'ec.jpg', 'available', 34),
(58, 'miniature', 'Ahmed Khan', 'Oil Paint', '22 x 30', 30000, 'eg.jpg', 'available', 34),
(59, 'miniature', 'Ahmed Khan', 'Oil on Canvas', '25 x 25', 35000, 'eh.jpg', 'available', 34),
(60, 'landscape', 'Ahmed Khan', 'Water Colour on Paper', '14 x 14', 23000, 'ce.jpg', 'available', 34),
(61, 'figurative', 'Ahmed Khan', 'Water Colour on Paper', '22 x 30', 200000, 'da.jpg', 'available', 34),
(62, 'figurative', 'Ahmed Khan', 'Oil on Canvas', '25 x 25', 250000, 'de.jpg', 'available', 34),
(63, 'abstract', 'Ahmed Khan', 'Oil on Canvas', '22 x 30', 23000, 'ab1.jpg', 'available', 34),
(64, 'abstract', 'Ahmed Khan', 'Water Colour on Paper', '22 x 30', 30000, 'ab3.jpg', 'available', 34),
(65, 'calligraphy', 'Abdul Jabbar Gull', 'Oil on Canvas', '25 x 25', 200000, 'bn.jpg', 'available', 16),
(66, 'figurative', 'Abdul Jabbar Gull', 'Oil on Canvas', '25 x 25', 23000, 'db.jpg', 'available', 16),
(67, 'figurative', 'Abdul Jabbar Gull', 'Oil on Canvas', '25 x 25', 200000, 'df.jpg', 'available', 16),
(68, 'figurative', 'Abdul Jabbar Gull', 'Water Colour on Paper', '30 x 36', 30000, 'fg2.jpg', 'available', 16),
(69, 'abstract', 'Abdul Jabbar Gull', 'Water Colour on Paper', '25 x 25', 23000, 'bc.jpg', 'available', 16),
(70, 'abstract', 'Abdul Jabbar Gull', 'Water Colour on Paper', '25 x 25', 100000, 'bd.jpg', 'available', 16),
(71, 'calligraphy', 'Ghulam  Mustafa', 'Water Colour on Paper', '25 x 25', 45000, 'regular_c6d17731-9aa0-4d0c-9fea-290dd347f498.jpg', 'available', 17),
(72, 'calligraphy', 'Ghulam  Mustafa', 'Oil on Canvas', '25 x 25', 50000, 'bd2af736410459.571b26df69d59.jpg', 'available', 17),
(73, 'calligraphy', 'Ghulam  Mustafa', 'Water Colour on Paper', '22 x 30', 130000, 'e49335a24e2955b4a9a7a4ef7f26a10a85b3d384.jpg', 'available', 17),
(74, 'calligraphy', 'Ghulam  Mustafa', 'Water Colour on Paper', '14 x 14', 200000, 'Image.jpg', 'available', 17),
(75, 'miniature', 'Ghulam  Mustafa', 'Water Colour on Paper', '14 x 14', 240000, 'eh.jpg', 'available', 17),
(76, 'miniature', 'Ghulam  Mustafa', 'Oil on Canvas', '25 x 25', 230000, 'Miniature-Madhubani-Madhubani-painting-Seema-03.jpeg', 'available', 17),
(77, 'miniature', 'Ghulam  Mustafa', 'Oil Paint', '45000', 40000, '179beb21c5adc479b3d5bb97a0404fa4.jpg', 'available', 17),
(78, 'calligraphy', 'Jamal Shah', 'Oil on Canvas', '22 x 30', 350000, 'Calligraphy-Art-copy.jpg', 'available', 18),
(79, 'calligraphy', 'Jamal Shah', 'Water Colour on Paper', '14 x 14', 450000, '8-done-400x400.jpg', 'available', 18),
(80, 'calligraphy', 'Jamal Shah', 'Oil Paint', '30 x 36', 360000, 'b.png', 'sold', 18),
(81, 'miniature', 'Jamal Shah', 'Water Colour on Paper', '22 x 30', 50000, 'Screenshot_4-3.jpg', 'available', 18),
(82, 'landscape', 'Jamal Shah', 'Oil on Canvas', '22 x 30', 460000, 'cf.jpg', 'available', 18),
(83, 'landscape', 'Jamal Shah', 'Water Colour on Paper', '30 x 36', 50000, 'ch.jpg', 'available', 18),
(84, 'landscape', 'Jamal Shah', 'Oil Paint', '30 x 36', 30000, 'cd.jpg', 'available', 18),
(85, 'landscape', 'Jamal Shah', 'Water Colour on Paper', '20 x 20', 46000, 'ce.jpg', 'available', 18),
(86, 'calligraphy', 'A.S  Rind', 'Water Colour on Paper', '25 x 25', 25000, '9.png', 'available', 15),
(87, 'calligraphy', 'A.S  Rind', 'Water Colour on Paper', '30 x 36', 10000, '7362002-HSC00001-6.jpg', 'available', 15),
(88, 'calligraphy', 'A.S  Rind', 'Water Colour on Paper', '20 x 20', 50000, '6931434-HSC00001-6.jpg', 'available', 15),
(89, 'calligraphy', 'A.S  Rind', 'Water Colour on Paper', '14 x 14', 100000, '07f408d9f27560a9d939a42aaea03d3f.jpg', 'available', 15);

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(225) NOT NULL,
  `userid` int(225) NOT NULL,
  `artid` int(225) NOT NULL,
  `pic` varchar(225) NOT NULL,
  `artist` varchar(225) NOT NULL,
  `type` varchar(225) NOT NULL,
  `medium` varchar(225) NOT NULL,
  `size` varchar(225) NOT NULL,
  `price` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `userid`, `artid`, `pic`, `artist`, `type`, `medium`, `size`, `price`) VALUES
(100, 57, 29, 'as rind.png ', 'da ', 'calligraphy ', 'hg ', ' h ', '0 '),
(101, 57, 30, 'abdul jabbar.jpg ', 'Hasa ', 'calligraphy ', 'adad ', ' adasddadasdasd ', '0 '),
(102, 54, 41, 'bi.jpg ', 'A.S  Rind ', 'calligraphy ', 'Ink Pen on Paper ', ' 20 x 20 ', '150000 '),
(123, 84, 79, '8-done-400x400.jpg ', 'Jamal Shah ', 'calligraphy ', 'Water Colour on Paper ', ' 14 x 14 ', '450000 '),
(124, 84, 72, 'bd2af736410459.571b26df69d59.jpg ', 'Ghulam  Mustafa ', 'calligraphy ', 'Oil on Canvas ', ' 25 x 25 ', '50000 '),
(125, 2, 89, '07f408d9f27560a9d939a42aaea03d3f.jpg ', 'A.S  Rind ', 'calligraphy ', 'Water Colour on Paper ', ' 14 x 14 ', '100000 '),
(126, 2, 40, 'fg1.jpg ', 'A.S  Rind ', 'figurative ', 'Water Colour on Paper ', ' 30 x 36 ', '200000 ');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int(225) NOT NULL,
  `userid` int(225) NOT NULL,
  `name` varchar(225) NOT NULL,
  `email` varchar(225) NOT NULL,
  `message` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `userid`, `name`, `email`, `message`) VALUES
(1, 64, 'shumaila', 'shumaila@gmail.com', 'abc'),
(2, 64, 'tanu', 'abcd@gmail.com', 'aa'),
(3, 0, 'shumaila', 'shumaila@gmail.com', 'aa'),
(4, 0, 'shumaila', 'shumaila@gmail.com', 'aa'),
(5, 0, 'shumaila', 'abcd@gmail.com', 'shvwefvwieufviwaufvw');

-- --------------------------------------------------------

--
-- Table structure for table `exhibitions`
--

CREATE TABLE `exhibitions` (
  `id` int(225) NOT NULL,
  `name` varchar(225) NOT NULL,
  `startdate` date NOT NULL,
  `enddate` date NOT NULL,
  `pic` varchar(225) NOT NULL,
  `status` enum('publish','offline','comingsoon') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `exhibitions`
--

INSERT INTO `exhibitions` (`id`, `name`, `startdate`, `enddate`, `pic`, `status`) VALUES
(21, 'Radiance Of Islamic Art', '2022-12-28', '2022-12-31', 'ezgif.com-gif-maker.jpg', 'comingsoon');

-- --------------------------------------------------------

--
-- Table structure for table `exhibition_arts`
--

CREATE TABLE `exhibition_arts` (
  `id` int(225) NOT NULL,
  `ex_id` int(225) NOT NULL,
  `artist` varchar(225) NOT NULL,
  `medium` varchar(225) NOT NULL,
  `size` varchar(225) NOT NULL,
  `price` int(225) NOT NULL,
  `pic` varchar(225) NOT NULL,
  `request` enum('accept','reject') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `exhibition_arts`
--

INSERT INTO `exhibition_arts` (`id`, `ex_id`, `artist`, `medium`, `size`, `price`, `pic`, `request`) VALUES
(33, 21, 'Mashkoor Raza', 'Water Colour on Paper', '25 x 25', 2000, 'persian-miniatures3.jpg', 'accept'),
(34, 21, 'Ali Abbas', 'Oil on Canvas', '14 x 14', 500000, 'bd2af736410459.571b26df69d59.jpg', 'accept'),
(35, 21, 'Abrar Ahmed', 'Oil Paint', '22 x 30', 130000, 'e49335a24e2955b4a9a7a4ef7f26a10a85b3d384.jpg', 'accept'),
(36, 21, 'Abrar Ahmed', 'Oil Paint', '30 x 36', 20000, 'Calligraphy-Art-copy.jpg', 'accept');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(255) NOT NULL,
  `userid` int(255) NOT NULL,
  `artid` int(225) NOT NULL,
  `fullname` varchar(225) NOT NULL,
  `email` varchar(225) NOT NULL,
  `city` varchar(225) NOT NULL,
  `state` varchar(225) NOT NULL,
  `address` varchar(225) NOT NULL,
  `phone` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `userid`, `artid`, `fullname`, `email`, `city`, `state`, `address`, `phone`) VALUES
(4, 0, 0, 'safAFADS', 'jwj@gamil.com', '$', 'R', '', '0'),
(5, 57, 29, '', 'u@gmail.com', 'u', 'u', 'u', '0'),
(6, 57, 30, '', 'u@gmail.com', 'u', 'u', 'u', '0'),
(7, 64, 29, 'tanu', 'tannu57775@gmail.com', 'ryk', 'ryk', 'abc', '300'),
(8, 64, 41, 'tanu', 'tannu57775@gmail.com', 'ryk', 'ryk', 'abc', '300'),
(9, 64, 41, 'tanu', 'tannu57775@gmail.com', 'ryk', 'ryk', 'abc', '0300-6736128'),
(10, 64, 42, 'tanu', 'tannu57775@gmail.com', 'ryk', 'ryk', 'abc', '0300-6736128'),
(11, 64, 41, 'tanzeel', 'tannu57775@gmail.com', 'ryk', 'ryk', 'abc', '0300-6736128'),
(12, 64, 42, 'tanzeel', 'tannu57775@gmail.com', 'ryk', 'ryk', 'abc', '0300-6736128'),
(13, 64, 30, 'tanzeel', 'tannu57775@gmail.com', 'ryk', 'ryk', 'abc', '0300-6736128'),
(14, 64, 38, 'tanzeel', 'tannu57775@gmail.com', 'ryk', 'ryk', 'abc', '0300-6736128'),
(15, 64, 29, 'tanzeel', 'tannu57775@gmail.com', 'ryk', 'ryk', 'abcd', '0300-6736128'),
(16, 75, 34, 'nn', 'stare@gmail.com', 'abc', 'ryk', 'abc', '0300-6736128'),
(17, 75, 39, 'mm', 'abcdm@gmail.com', 'abc', 'abc', 'abc', '0300-6736128'),
(18, 64, 29, '', '', '', '', '', ''),
(19, 64, 31, '', '', '', '', '', ''),
(20, 64, 44, 'shumaila', 'stare0686@gmail.com', 'aaa', 'aaa', 'aaa', '0300-6736128'),
(21, 64, 36, 'shumaila', 'stare0686@gmail.com', 'aaa', 'aaa', 'aaa', '0300-6736128'),
(22, 82, 42, 'tanzeel', 'tannu57775@gmail.com', 'ryk', 'ryk', 'satellite town', '0300-6736128'),
(23, 82, 41, 'tanzeel', 'tannu57775@gmail.com', 'ryk', 'ryk', 'ryk', '0300-6736128'),
(24, 83, 80, '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(225) NOT NULL,
  `fname` varchar(225) NOT NULL,
  `lname` varchar(225) NOT NULL,
  `phone` varchar(225) NOT NULL,
  `email` varchar(225) NOT NULL,
  `role` enum('admin','user','artist') NOT NULL,
  `username` varchar(225) NOT NULL,
  `password` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fname`, `lname`, `phone`, `email`, `role`, `username`, `password`) VALUES
(1, '', '', '0', '', 'admin', 'admin', '1234'),
(2, 'Tanzeel', 'Tariq', '03124887598', 'user123@gmail.com', 'user', 'user', '123'),
(52, 'Arif', 'Khan', '03161234567', 'aa@gmail.com', 'artist', 'arif', '123'),
(54, 'A.S', 'Rind', '03001122334', 'rind@gmai.com', 'artist', 'rind', '123'),
(55, 'Abdul Jabbar', 'Gull', '03121234567', 'abdul@gmail.com', 'artist', 'abdul', '123'),
(56, 'Ghulam ', 'Mustafa', '03091234567', 'Ghulam@gmail.com', 'artist', 'ghulam', '123'),
(57, 'Jamal', 'Shah', '03451237891', 'jamalshah@gmaill.com', 'artist', 'jamal', '123'),
(58, 'Bilal ', 'Tariq', '03091234896', 'abcd@gmail.com', 'user', 'bilal', '123'),
(59, 'Shahrukh', 'Ali', '03087293895', 'abcd@gmail.com', 'artist', 'ali', '123'),
(60, 'Tanzeel', 'Tariq', '03128965477', 'abcd@gmail.com', 'user', 'tanzeel', '123'),
(61, 'Shumaila', 'Arif', '03061287655', '123@gmail.com', 'user', 'shumaila', '123'),
(62, 'Abdul', 'Rehman', '03007877654', 'abcd@gmail.com', 'artist', 'abdulrehman', '123'),
(63, 'Ahmed', 'Khan', '0300-6736128', 'abcd@gmail.com', 'artist', 'ahmed', '123'),
(64, 'Hajra', 'Mansoor', '0300-6736128', 'user@gmail.com', 'artist', 'hajra', '123'),
(83, 'acc', 'ab', '03008841241', 'abzz@gmail.com', 'user', 'acc', 'zzzz'),
(84, 'shyle', 'arif', '03008841241', 'arif@mail.com', 'artist', 'shyle', 'abcd');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `artists`
--
ALTER TABLE `artists`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `arts`
--
ALTER TABLE `arts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `exhibitions`
--
ALTER TABLE `exhibitions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `exhibition_arts`
--
ALTER TABLE `exhibition_arts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `artists`
--
ALTER TABLE `artists`
  MODIFY `id` int(225) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `arts`
--
ALTER TABLE `arts`
  MODIFY `id` int(225) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=90;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(225) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=127;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(225) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `exhibitions`
--
ALTER TABLE `exhibitions`
  MODIFY `id` int(225) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `exhibition_arts`
--
ALTER TABLE `exhibition_arts`
  MODIFY `id` int(225) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(225) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=85;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
