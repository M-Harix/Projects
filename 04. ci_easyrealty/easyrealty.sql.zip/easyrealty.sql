-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 23, 2024 at 02:13 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `easyrealty`
--

-- --------------------------------------------------------

--
-- Table structure for table `ci_sessions`
--

CREATE TABLE `ci_sessions` (
  `session_id` varchar(40) NOT NULL DEFAULT '0',
  `ip_address` varchar(45) NOT NULL DEFAULT '0',
  `user_agent` varchar(120) NOT NULL,
  `last_activity` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `user_data` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `msg_id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `message` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`msg_id`, `name`, `email`, `message`) VALUES
(1, 'Haris', 'muhammad_harrix@gmail.com', 'faf'),
(2, 'haris', 'muhammadharis@gmail.com', 'ss'),
(3, 'Haris', 'muhammadharis@gmail.com', 'wwwwwwww'),
(4, 'Haris', 'muhammadharis@gmail.com', 'ss'),
(5, 'Haris', 'muhammadharis@gmail.com', '1');

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE `images` (
  `imgid` int(255) NOT NULL,
  `propertyid` int(255) NOT NULL,
  `imagename` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `images`
--

INSERT INTO `images` (`imgid`, `propertyid`, `imagename`) VALUES
(76, 21, 'WhatsApp Image 2022-05-31 at 2.01.18 PM (1).jpeg'),
(77, 21, 'WhatsApp Image 2022-05-31 at 2.01.18 PM.jpeg'),
(78, 21, 'WhatsApp Image 2022-05-31 at 2.01.19 PM (1).jpeg'),
(79, 21, 'WhatsApp Image 2022-05-31 at 2.01.19 PM.jpeg'),
(80, 21, 'WhatsApp Image 2022-05-31 at 2.01.20 PM (1).jpeg'),
(81, 124, 'WhatsApp Image 2022-05-31 at 2.01.20 PM.jpeg'),
(82, 21, 'WhatsApp Image 2022-05-31 at 2.01.21 PM (1).jpeg'),
(83, 21, 'WhatsApp Image 2022-05-31 at 2.01.21 PM (2).jpeg'),
(84, 21, 'WhatsApp Image 2022-05-31 at 2.01.21 PM.jpeg'),
(85, 21, 'WhatsApp Image 2022-05-31 at 2.01.22 PM (1).jpeg'),
(86, 21, 'WhatsApp Image 2022-05-31 at 2.01.22 PM.jpeg'),
(87, 21, 'WhatsApp Image 2022-05-31 at 2.01.23 PM (1).jpeg'),
(88, 21, 'WhatsApp Image 2022-05-31 at 2.01.23 PM.jpeg'),
(89, 22, 'WhatsApp Image 2022-06-09 at 11.21.25 AM (2).jpeg'),
(90, 22, 'WhatsApp Image 2022-06-09 at 11.21.25 AM.jpeg'),
(91, 22, 'WhatsApp Image 2022-06-09 at 11.21.26 AM (1).jpeg'),
(92, 22, 'WhatsApp Image 2022-06-09 at 11.21.26 AM (2).jpeg'),
(93, 22, 'WhatsApp Image 2022-06-09 at 11.21.26 AM (3).jpeg'),
(94, 22, 'WhatsApp Image 2022-06-09 at 11.21.26 AM.jpeg'),
(95, 22, 'WhatsApp Image 2022-06-09 at 11.21.27 AM.jpeg'),
(102, 24, 'WhatsApp Image 2022-05-31 at 2.01.24 PM (2).jpeg'),
(103, 24, 'WhatsApp Image 2022-05-31 at 2.01.24 PM.jpeg'),
(104, 24, 'WhatsApp Image 2022-05-31 at 2.01.25 PM (1).jpeg'),
(105, 24, 'WhatsApp Image 2022-05-31 at 2.01.25 PM.jpeg'),
(106, 24, 'WhatsApp Image 2022-05-31 at 2.01.26 PM (1).jpeg'),
(107, 24, 'WhatsApp Image 2022-05-31 at 2.01.26 PM.jpeg'),
(108, 24, 'WhatsApp Image 2022-05-31 at 2.01.27 PM (1).jpeg'),
(109, 25, 'WhatsApp Image 2022-06-09 at 10.57.54 AM (1).jpeg'),
(110, 25, 'WhatsApp Image 2022-06-09 at 10.57.54 AM.jpeg'),
(111, 25, 'WhatsApp Image 2022-06-09 at 10.57.55 AM (1).jpeg'),
(112, 25, 'WhatsApp Image 2022-06-09 at 10.57.55 AM (2).jpeg'),
(113, 25, 'WhatsApp Image 2022-06-09 at 10.57.55 AM (3).jpeg'),
(114, 25, 'WhatsApp Image 2022-06-09 at 10.57.55 AM.jpeg'),
(115, 25, 'WhatsApp Image 2022-06-09 at 10.57.56 AM (1).jpeg'),
(116, 25, 'WhatsApp Image 2022-06-09 at 10.57.56 AM.jpeg'),
(117, 25, 'WhatsApp Image 2022-06-09 at 10.57.57 AM.jpeg'),
(118, 26, 'WhatsApp Image 2022-06-09 at 11.02.31 AM (1).jpeg'),
(119, 26, 'WhatsApp Image 2022-06-09 at 11.02.31 AM.jpeg'),
(120, 26, 'WhatsApp Image 2022-06-09 at 11.02.32 AM (1).jpeg'),
(121, 26, 'WhatsApp Image 2022-06-09 at 11.02.32 AM (2).jpeg'),
(122, 26, 'WhatsApp Image 2022-06-09 at 11.02.36 AM.jpeg'),
(123, 26, 'WhatsApp Image 2022-06-09 at 11.02.37 AM.jpeg'),
(129, 28, 'WhatsApp Image 2022-05-31 at 2.04.22 PM (1).jpeg'),
(130, 28, 'WhatsApp Image 2022-05-31 at 2.04.22 PM.jpeg'),
(131, 28, 'WhatsApp Image 2022-05-31 at 2.04.23 PM (1).jpeg'),
(132, 28, 'WhatsApp Image 2022-05-31 at 2.04.23 PM (2).jpeg'),
(133, 28, 'WhatsApp Image 2022-05-31 at 2.04.23 PM.jpeg'),
(134, 29, 'WhatsApp Image 2022-06-09 at 10.39.41 AM.jpeg'),
(135, 29, 'WhatsApp Image 2022-06-09 at 10.39.42 AM (1).jpeg'),
(136, 29, 'WhatsApp Image 2022-06-09 at 10.39.42 AM.jpeg'),
(137, 29, 'WhatsApp Image 2022-06-09 at 10.39.43 AM (1).jpeg'),
(138, 29, 'WhatsApp Image 2022-06-09 at 10.39.43 AM (2).jpeg'),
(139, 29, 'WhatsApp Image 2022-06-09 at 10.39.43 AM.jpeg'),
(146, 31, 'WhatsApp Image 2022-06-09 at 10.39.41 AM.jpeg'),
(147, 31, 'WhatsApp Image 2022-06-09 at 10.39.42 AM (1).jpeg'),
(148, 31, 'WhatsApp Image 2022-06-09 at 10.39.42 AM.jpeg'),
(149, 31, 'WhatsApp Image 2022-06-09 at 10.39.43 AM (1).jpeg'),
(150, 31, 'WhatsApp Image 2022-06-09 at 10.39.43 AM (2).jpeg'),
(151, 31, 'WhatsApp Image 2022-06-09 at 10.39.43 AM.jpeg'),
(152, 32, 'WhatsApp Image 2022-06-09 at 10.39.41 AM.jpeg'),
(153, 32, 'WhatsApp Image 2022-06-09 at 10.39.42 AM (1).jpeg'),
(154, 32, 'WhatsApp Image 2022-06-09 at 10.39.42 AM.jpeg'),
(155, 32, 'WhatsApp Image 2022-06-09 at 10.39.43 AM (1).jpeg'),
(156, 32, 'WhatsApp Image 2022-06-09 at 10.39.43 AM (2).jpeg'),
(157, 32, 'WhatsApp Image 2022-06-09 at 10.39.43 AM.jpeg'),
(163, 34, 'WhatsApp Image 2022-05-31 at 2.02.14 PM (1).jpeg'),
(164, 35, 'WhatsApp Image 2022-05-31 at 2.01.22 PM (1).jpeg'),
(165, 36, 'WhatsApp Image 2022-05-31 at 2.04.22 PM (1).jpeg'),
(166, 36, 'WhatsApp Image 2022-05-31 at 2.04.22 PM.jpeg'),
(167, 36, 'WhatsApp Image 2022-05-31 at 2.04.23 PM (1).jpeg'),
(168, 36, 'WhatsApp Image 2022-05-31 at 2.04.23 PM (2).jpeg'),
(169, 37, 'WhatsApp Image 2022-05-31 at 2.01.22 PM.jpeg'),
(171, 39, 'WhatsApp Image 2022-05-31 at 2.02.11 PM (1).jpeg'),
(172, 33, 'rwrwrrw'),
(173, 100, '1659289657modern_home_property_logo.png'),
(174, 100, '1659289707modern_home_property_logo.png'),
(175, 101, '1659289746Pink_Simple_Creative_And_Professional_Medical_Home_Logo_Design_Template_(8).png'),
(176, 102, '1659289759r.png'),
(177, 103, '1659289818modern_home_property_logo.png'),
(179, 105, '1659295153Modern_Minimal_Letter_M_Photographer_Initials_Logo.png'),
(180, 106, '1659295216Modern_Minimal_Letter_M_Photographer_Initials_Logo.png'),
(181, 107, '1659295255logo.png'),
(182, 108, '1659295293Untitled_design.png'),
(183, 122, 'Untitled design (2).png'),
(184, 122, 'r.png'),
(185, 123, 'atherbro.png'),
(186, 123, 'Pink Simple Creative And Professional Medical Home Logo Design Template (16).png'),
(187, 123, 'Pink Simple Creative And Professional Medical Home Logo Design Template (15).png'),
(188, 123, 'Pink Simple Creative And Professional Medical Home Logo Design Template (14).png'),
(189, 123, 'Pink Simple Creative And Professional Medical Home Logo Design Template (13).png'),
(190, 123, 'Pink Simple Creative And Professional Medical Home Logo Design Template (12).png'),
(191, 123, 'Pink Simple Creative And Professional Medical Home Logo Design Template (11).png'),
(192, 123, 'Pink Simple Creative And Professional Medical Home Logo Design Template (10).png'),
(193, 123, 'Pink Simple Creative And Professional Medical Home Logo Design Template (9).png'),
(194, 123, 'Pink Simple Creative And Professional Medical Home Logo Design Template (8).png'),
(195, 123, 'Pink Simple Creative And Professional Medical Home Logo Design Template (7).png'),
(196, 123, 'Pink Simple Creative And Professional Medical Home Logo Design Template (2).png'),
(197, 123, 'Pink Simple Creative And Professional Medical Home Logo Design Template (1).png'),
(198, 123, 'Pink Simple Creative And Professional Medical Home Logo Design Template.png'),
(199, 123, 'Luxury real estate building logo.png'),
(200, 124, 'Luxury real estate building logo.png'),
(201, 125, 'Black Simple Body Building Modern Gym Logo.png'),
(202, 126, 'Pink Simple Creative And Professional Medical Home Logo Design Template (10).png'),
(203, 127, 'Pink Simple.png'),
(204, 128, 'atherbro-removebg-preview.png'),
(205, 129, 'WhatsApp Image.jpeg'),
(206, 129, 'WhatsApp Image 2022-05-31 at 2.02.16 PM (1).jpeg'),
(207, 129, 'WhatsApp Image 2022-05-31 at 2.02.16 PM.jpeg'),
(208, 129, 'WhatsApp Image 2022-05-31 at 2.02.17 PM (1).jpeg'),
(209, 129, 'WhatsApp Image 2022-05-31 at 2.02.17 PM.jpeg'),
(210, 129, 'WhatsApp Image 2022-05-31 at 2.02.18 PM (1).jpeg'),
(211, 129, 'WhatsApp Image 2022-05-31 at 2.02.18 PM (2).jpeg'),
(212, 129, 'WhatsApp Image 2022-05-31 at 2.02.18 PM.jpeg'),
(213, 129, 'WhatsApp Image 2022-05-31 at 2.02.19 PM (1).jpeg'),
(214, 129, 'WhatsApp Image 2022-05-31 at 2.02.20 PM (1).jpeg'),
(215, 129, 'WhatsApp Image 2022-05-31 at 2.02.20 PM.jpeg'),
(216, 129, 'WhatsApp Image 2022-05-31 at 2.02.21 PM (1).jpeg'),
(217, 129, 'WhatsApp Image 2022-05-31 at 2.02.21 PM (2).jpeg'),
(218, 129, 'WhatsApp Image 2022-05-31 at 2.02.21 PM.jpeg'),
(219, 129, 'WhatsApp Image 2022-05-31 at 2.02.22 PM (1).jpeg'),
(220, 129, 'WhatsApp Image 2022-05-31 at 2.02.22 PM.jpeg'),
(221, 129, 'WhatsApp Image 2022-05-31 at 2.02.23 PM (1).jpeg'),
(222, 129, 'WhatsApp Image 2022-05-31 at 2.02.23 PM (2).jpeg'),
(223, 130, 'modern home property logo.png'),
(224, 131, 'modern home property logo.png'),
(225, 132, 'atherbro.png'),
(226, 133, 'atherbro.png'),
(227, 134, '20200104_201904.jpg'),
(228, 134, '20200104_201910.jpg'),
(229, 134, '20200104_201912.jpg'),
(230, 134, '20200104_202800.jpg'),
(231, 134, '20200104_202801.jpg'),
(232, 134, '20200104_202805.jpg'),
(233, 134, '20200104_202809.jpg'),
(234, 134, 'IMG-20200210-WA0017.jpg'),
(235, 135, '20200104_201904.jpg'),
(236, 135, '20200104_201910.jpg'),
(237, 135, '20200104_201912.jpg'),
(238, 135, '20200104_202800.jpg'),
(239, 135, '20200104_202801.jpg'),
(240, 135, '20200104_202805.jpg'),
(241, 135, '20200104_202809.jpg'),
(242, 135, 'IMG-20200210-WA0017.jpg'),
(243, 136, 'Untitled design (2).png'),
(244, 137, 'Untitled design (2).png'),
(245, 138, 'Untitled design (2).png'),
(246, 139, 'logo.png'),
(247, 140, 'r.png'),
(248, 140, 'Luxury real estate building logo.png'),
(249, 141, 'r.png'),
(250, 141, 'Luxury real estate building logo.png'),
(251, 142, 'r.png'),
(252, 142, 'Luxury real estate building logo.png'),
(253, 143, 'r.png'),
(254, 143, 'Luxury real estate building logo.png'),
(255, 144, 'Pink Simple Creative And Professional Medical Home Logo Design Template (16).png'),
(256, 144, 'Pink Simple Creative And Professional Medical Home Logo Design Template (15).png'),
(257, 144, 'Pink Simple Creative And Professional Medical Home Logo Design Template (14).png'),
(258, 145, 'Pink Simple Creative And Professional Medical Home Logo Design Template (16).png'),
(259, 145, 'Pink Simple Creative And Professional Medical Home Logo Design Template (15).png'),
(260, 145, 'Pink Simple Creative And Professional Medical Home Logo Design Template (14).png'),
(261, 146, 'WhatsApp Image 2022-05-31 at 2.04.22 PM (1).jpeg'),
(262, 146, 'WhatsApp Image 2022-05-31 at 2.04.22 PM.jpeg'),
(263, 146, 'WhatsApp Image 2022-05-31 at 2.04.23 PM (1).jpeg'),
(264, 146, 'WhatsApp Image 2022-05-31 at 2.04.23 PM (2).jpeg'),
(265, 147, 'logo.png'),
(266, 148, 'Untitled design (2).png');

-- --------------------------------------------------------

--
-- Table structure for table `properties`
--

CREATE TABLE `properties` (
  `propertyid` int(255) NOT NULL,
  `purpose` enum('rent','forsale') NOT NULL,
  `address` varchar(255) NOT NULL,
  `category` enum('house','plot','commercial') NOT NULL,
  `description` varchar(255) NOT NULL,
  `price` int(255) NOT NULL,
  `area` varchar(255) NOT NULL,
  `whatsapp` varchar(255) NOT NULL,
  `status` enum('online','offline') NOT NULL,
  `userid` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `properties`
--

INSERT INTO `properties` (`propertyid`, `purpose`, `address`, `category`, `description`, `price`, `area`, `whatsapp`, `status`, `userid`) VALUES
(21, 'forsale', 'Abbasia Town', 'house', 'Unfurnished,\r\n6 Bedrooms', 16000000, '7 Marla', '03036136983', 'offline', 0),
(24, 'forsale', 'Skhi Sarwar Colony', 'house', '5 Bedrooms\r\n5 Bathrooms', 6000000, '6 Marla', '03036136983', 'offline', 0),
(25, 'rent', 'Gulshan Iqbal', 'house', 'Unfurnished\r\n3 Bedrooms', 15000, '6 Marla', '03036136983', 'offline', 0),
(26, 'rent', 'Gulshan Iqbal', 'house', 'Unfurnished\r\n4 Bathrooms\r\n6 Bedrooms', 16000, '8 Marla', '03036136983', 'online', 0),
(31, 'forsale', 'Dari Sangi', 'commercial', '4 Bedrooms', 5200000, '5 Marla', '03036136983', 'online', 0),
(32, 'rent', 'Dari Sangi', 'house', '4 Bedrooms', 25000, '5 Marla', '03036136983', 'online', 0),
(34, 'rent', 'Satellite town', 'house', '5 bedrooms\r\n', 100000, '5 Marla', '03001234567', 'online', 0),
(35, 'forsale', 'hjgjhgjg', '', 'hjkghkg', 5656756, '434356dg', '57658756875', 'online', 0),
(36, 'forsale', 'Gulshan Iqbal', 'house', '5 Bedrooms\r\n2 Bathroom', 5100000, '6 Marly', '03001112234', 'online', 0),
(37, 'rent', 'Abbasia Town', 'house', '5 Bedrooms', 18000, '4 Marly', '7696969679', 'online', 0),
(39, 'rent', 'Satellite Town', 'house', '3 Bedrooms', 12000, '4 Marla', '03009851099', 'online', 0),
(40, 'forsale', 'aSD', 'commercial', 'S', 22, '21', '209', 'online', 0),
(41, 'forsale', 'asdd', 'house', 'adada', 3333, '333', '329', 'online', 0),
(42, 'forsale', 'asdd', 'commercial', 'adada', 3333, '333', '329', 'online', 0),
(43, 'forsale', 'asdd', 'plot', 'adada', 3333, '333', '329', 'online', 0),
(44, 'rent', 'wrer', 'house', 'rqrw', 444, '444', '444', 'online', 0),
(45, 'rent', 'wrer', 'plot', 'rqrw', 444, '444', '444', 'online', 0),
(46, 'rent', 'wrer', 'commercial', 'rqrw', 444, '444', '444', 'online', 0),
(47, 'rent', 'wrer', 'house', 'rqrw', 444, '444', '444', 'online', 0),
(48, 'rent', 'wrer', 'plot', 'rqrw', 444, '444', '444', 'online', 0),
(49, 'rent', 'wrer', 'plot', 'rqrw', 444, '444', '444', 'online', 0),
(50, 'forsale', 'eqe', 'plot', 'eqe', 2, '2', '2', 'online', 0),
(51, 'forsale', 'eqe', 'commercial', 'eqe', 2, '2', '2', 'online', 0),
(52, 'forsale', 'eqe', 'house', 'eqe', 2, '2', '2', 'online', 0),
(53, 'rent', 'wrer', 'commercial', 'rqrw', 444, '444', '444', 'online', 0),
(54, 'rent', 'wrer', 'commercial', 'rqrw', 444, '444', '444', 'online', 0),
(55, 'rent', 'wrer', 'house', 'rqrw', 444, '444', '444', 'online', 0),
(56, 'rent', 'wrer', 'commercial', 'rqrw', 444, '444', '444', 'online', 0),
(57, 'rent', 'wrer', 'plot', 'rqrw', 444, '444', '444', 'online', 0),
(58, 'rent', 'wrer', 'house', 'rqrw', 444, '444', '444', 'online', 0),
(59, 'rent', 'wrer', 'house', 'rqrw', 444, '444', '444', 'online', 0),
(60, 'rent', 'wrer', 'plot', 'rqrw', 444, '444', '444', 'online', 0),
(61, 'rent', 'wrer', 'commercial', 'rqrw', 444, '444', '444', 'online', 0),
(62, 'rent', 'wrer', 'house', 'rqrw', 444, '444', '444', 'online', 0),
(63, 'rent', 'wrer', 'plot', 'rqrw', 444, '444', '444', 'offline', 0),
(64, 'rent', 'wrer', 'commercial', 'rqrw', 444, '444', '444', 'online', 0),
(65, 'rent', 'wrer', '', 'rqrw', 444, '444', '444', 'offline', 0),
(66, 'rent', 'wrer', '', 'rqrw', 444, '444', '444', 'online', 0),
(67, 'rent', 'wrer', '', 'rqrw', 444, '444', '444', 'offline', 0),
(68, 'rent', 'wrer', '', 'rqrw', 444, '444', '444', 'online', 0),
(69, 'rent', 'wrer', '', 'rqrw', 444, '444', '444', 'offline', 0),
(70, 'rent', 'wrer', '', 'rqrw', 444, '444', '444', 'offline', 0),
(71, 'rent', 'wrer', '', 'rqrw', 444, '444', '444', 'online', 0),
(72, 'rent', 'wrer', '', 'rqrw', 444, '444', '444', 'online', 0),
(73, 'rent', 'wrer', '', 'rqrw', 444, '444', '444', 'offline', 0),
(74, 'rent', 'wrer', '', 'rqrw', 444, '444', '444', 'online', 0),
(75, 'rent', 'wrer', '', 'rqrw', 444, '444', '444', 'online', 0),
(76, 'rent', 'wrer', '', 'rqrw', 444, '444', '444', 'online', 0),
(77, 'rent', 'wrer', '', 'rqrw', 444, '444', '444', 'online', 0),
(78, 'rent', 'wrer', '', 'rqrw', 444, '444', '444', 'online', 0),
(79, 'rent', 'wrer', '', 'rqrw', 444, '444', '444', 'online', 0),
(80, 'forsale', 'asd', 'plot', 'hkh', 78, '78', '78', 'online', 0),
(81, 'forsale', 'asd', 'house', 'hkh', 78, '78', '78', 'online', 0),
(82, 'forsale', 'asd', 'house', 'hkh', 78, '78', '78', 'online', 0),
(83, 'forsale', 'asd', 'plot', 'hkh', 78, '78', '78', 'online', 0),
(84, 'forsale', 'asd', 'commercial', 'hkh', 78, '78', '78', 'online', 0),
(85, 'forsale', 'asd', 'house', 'hkh', 78, '78', '78', 'online', 0),
(86, 'forsale', 'eqe', 'plot', 'eqe', 2, '2', '2', 'online', 0),
(87, 'rent', 'wewe', '', 'wewe', 333, '333', '333', 'online', 0),
(88, 'rent', 'eqe', 'commercial', 'eqe', 2, '2', '2', 'online', 0),
(89, 'rent', 'wewe', '', 'wewe', 333, '333', '333', 'online', 0),
(90, 'rent', 'wewe', '', 'wewe', 333, '333', '333', 'online', 0),
(91, 'rent', 'wewe', '', 'wewe', 333, '333', '333', 'online', 0),
(92, 'rent', 'eqe', 'house', 'eqe', 2, '2', '2', 'online', 0),
(93, 'rent', 'eqe', 'plot', 'eqe', 2, '2', '2', 'online', 0),
(94, 'rent', 'xx', 'house', 'xx', 22, '222', '19', 'online', 0),
(95, 'rent', 'xx', 'house', 'xx', 22, '222', '19', 'offline', 0),
(96, 'rent', 'xx', 'plot', 'xx', 22, '222', '19', 'online', 0),
(97, 'rent', 'xx', 'plot', 'xx', 22, '222', '19', 'online', 0),
(98, 'rent', 'xx', 'plot', 'xx', 22, '222', '19', 'online', 0),
(99, 'rent', 'xx', 'commercial', 'xx', 22, '222', '19', 'online', 0),
(100, 'rent', 'wewe', '', 'wewe', 333, '333', '333', 'online', 0),
(101, 'rent', 'xx', 'commercial', 'xx', 22, '222', '19', 'online', 0),
(102, 'rent', 'eqe', 'plot', 'eqe', 2, '2', '2', 'online', 0),
(103, 'rent', 'wewe', '', 'wewe', 333, '333', '333', 'online', 0),
(104, 'rent', 'wewe', '', 'wewe', 333, '333', '333', 'online', 0),
(105, 'forsale', 'sss', '', 'sss', 222, '222', '220', 'online', 0),
(106, 'forsale', 'sss', '', 'sss', 222, '222', '220', 'online', 0),
(107, 'forsale', 'sss', '', 'sss', 222, '222', '220', 'online', 0),
(108, 'forsale', 'sss', '', 'sss', 222, '222', '220', 'online', 0),
(109, 'forsale', 'qe', 'plot', 'tt', 77, '77', '77', 'online', 0),
(110, 'forsale', 'qe', 'commercial', 'tt', 77, '77', '77', 'online', 0),
(111, 'forsale', 'qe', 'plot', 'tt', 77, '77', '77', 'online', 0),
(112, 'forsale', 'qe', 'commercial', 'tt', 77, '77', '77', 'online', 0),
(113, 'forsale', 'qe', 'house', 'tt', 77, '77', '77', 'online', 0),
(114, 'rent', '555', 'house', '555', 5, '55', '5', 'online', 0),
(115, 'rent', '555', 'plot', '555', 5, '55', '5', 'online', 0),
(116, 'rent', '555', 'plot', '555', 5, '55', '5', 'online', 0),
(117, 'rent', '555', 'commercial', '555', 5, '55', '5', 'online', 0),
(118, 'rent', '555', 'house', '555', 5, '55', '5', 'online', 0),
(119, 'forsale', 'qe', 'house', 'tt', 77, '77', '77', 'online', 0),
(120, 'forsale', 'wq', 'commercial', 'we', 33, '33', '33', 'online', 0),
(121, 'forsale', 'wq', '', 'we', 33, '33', '33', 'online', 0),
(122, 'forsale', 'pppp', '', 'ppp', 999, '999', '996', 'online', 0),
(123, 'forsale', 'pppp', '', 'ppp', 999, '999', '996', 'online', 0),
(124, 'forsale', 'pppp', 'plot', 'ppp', 999, '999', '996', 'online', 0),
(125, 'forsale', 'pppp', '', 'ppp', 999, '999', '996', 'online', 0),
(126, 'rent', '5646', 'house', '667', 7777, '777', '777', 'online', 0),
(127, 'rent', '555', 'plot', '55', 55, '555', '555', 'online', 0),
(128, 'rent', '555', 'commercial', '55', 55, '555', '555', 'online', 0),
(129, 'rent', '555', '', '55', 55, '555', '555', 'online', 0),
(130, 'rent', '555', '', '55', 55, '555', '555', 'online', 0),
(131, 'rent', '555', '', '55', 55, '555', '555', 'online', 0),
(132, 'rent', '555', '', '55', 55, '555', '555', 'online', 0),
(133, 'rent', '11', 'house', '1', 1, '1', '1', 'online', 0),
(134, 'rent', '11', 'house', '1', 1, '1', '1', 'online', 0),
(135, 'rent', '11', 'house', '1', 1, '1', '1', 'online', 0),
(136, 'forsale', 'Dase', 'commercial', 'sddf fsdf w', 34222, '5 marla', '443356', 'online', 0),
(137, 'forsale', 'Dase', 'plot', 'sddf fsdf w', 34222, '5 marla', '443356', 'online', 0),
(138, 'forsale', 'Dase', 'house', 'sddf fsdf w', 34222, '5 marla', '443356', 'online', 28),
(139, 'forsale', 'gyh', 'house', 'no', 9000, '4m', '0300', 'online', 28),
(140, 'forsale', 'gul', 'house', 'no', 8999, '4m', '0300', 'online', 28),
(141, 'rent', 'gul', 'house', 'no', 8999, '4m', '0300', 'online', 0),
(142, 'rent', 'gul', 'plot', 'no', 8999, '4m', '0300', 'online', 28),
(143, 'rent', 'gul', 'commercial', 'no', 8999, '4m', '0300', 'online', 28),
(146, 'forsale', 'qq', 'plot', 'qq', 8909, '67', '900', 'offline', 28),
(147, 'rent', 'aa', 'house', 'aa', 22, '22', '22', 'offline', 28),
(148, 'forsale', 'z', 'house', 't8', 8, 't', '8', 'offline', 28);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `userid` int(255) NOT NULL,
  `role` enum('admin','serviceprovider','user') NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `phone` longtext NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userid`, `role`, `firstname`, `lastname`, `phone`, `email`, `password`) VALUES
(3, 'admin', 'Muhammad', 'Haris ', '03036136983', 'muhammadharis@gmail.com', '2222'),
(4, 'user', 'Muhammad', 'Taimoor', '0306744841', 'taimoorghaffar7788@gmail.com', '5ec0e37a3cbab82b0e5ae05e3cc01eed'),
(6, 'user', 'taimoor', 'ghaffar', '0300123456', 'taimoor@gmail.com', '0fd7ea9ac93aae491370c228d17d2a56'),
(7, 'admin', 'sd', 'sd', 'ad', 'haris@gmail.com', 'easyrealty'),
(8, 'admin', 'sd', 'sd', 'ad', 'muhammadharis@gmail.com', 'easyrealty'),
(9, 'admin', 'sd', 'sd', 'adaaaa', 'muhammadharis@gmail.com', 'easyrealty'),
(10, 'user', 'sd', 'sd', 'adaaaa', 'muhammadharis@gmail.com', 'easyrealty'),
(11, 'admin', 'sd', 'sd', 'adaaaa', 'muhammadharis@gmail.com', 'easyrealty'),
(12, 'user', 'sd', 'sd', 'adaaaa', 'muhammadharis@gmail.com', 'easyrealty'),
(13, 'user', 'sd', 'sd', 'adaaaa', 'muhammadharis@gmail.com', 'easyrealty'),
(14, 'user', 'sd', 'sd', 'adaaaa', 'muhammadharis@gmail.com', 'easyrealty'),
(15, 'user', 'sd', 'sd', 'adaaaa', 'muhammadharis@gmail.com', 'easyrealty'),
(16, 'user', 'sd', 'sd', 'adaaaa', 'muhammadharis@gmail.com', 'easyrealty'),
(17, 'user', 'sd', 'sd', 'adaaaa', 'muhammadharis@gmail.com', 'easyrealty'),
(18, 'user', 'sd', 'sd', 'adaaaa', 'muhammadharis@gmail.com', 'easyrealty'),
(19, 'user', 'sd', 'sd', 'adaaaa', 'muhammadharis@gmail.com', 'easyrealty'),
(20, 'user', 'sd', 'sd', 'adaaaa', 'muhammadharis@gmail.com', 'easyrealty'),
(21, 'user', 'sd', 'sd', 'adaaaa', 'muhammadharis@gmail.com', 'easyrealty'),
(22, 'user', 'sd', 'sd', 'adaaaa', 'muhammadharis@gmail.com', 'easyrealty'),
(23, 'user', 'sd', 'sd', 'adaaaa', 'muhammadharis@gmail.com', 'easyrealty'),
(24, 'user', 'sd', 'sd', 'adaaaa', 'muhammadharis@gmail.com', 'easyrealty'),
(25, 'user', 'sd', 'sd', 'adaaaa', 'muhammadharis@gmail.com', 'adasd'),
(26, 'user', 'aa', 'aa', 'aa', 'muhammadharis@gmail.com', 'aa'),
(27, 'user', 'sd', 'sd', 'adaaaa', 'muhammadharis@gmail.com', 'easyrealty'),
(28, 'user', 'aaaa', 'dddd', '333', 'muhammadharis@gmail.com', 'easyrealty');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ci_sessions`
--
ALTER TABLE `ci_sessions`
  ADD PRIMARY KEY (`session_id`),
  ADD KEY `last_activity_idx` (`last_activity`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`msg_id`);

--
-- Indexes for table `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`imgid`);

--
-- Indexes for table `properties`
--
ALTER TABLE `properties`
  ADD PRIMARY KEY (`propertyid`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `msg_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `images`
--
ALTER TABLE `images`
  MODIFY `imgid` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=267;

--
-- AUTO_INCREMENT for table `properties`
--
ALTER TABLE `properties`
  MODIFY `propertyid` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=149;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `userid` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
